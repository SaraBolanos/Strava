package es.deusto.sd.strava.enums;

public enum TargetType {
		TIME,DISTANCE
}
