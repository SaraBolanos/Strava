package es.deusto.sd.strava.enums;

public enum Sport {
		RUNNING, CYCLING
}
