package es.deusto.sd.strava.client.enums;

public enum TargetType {
	TIME,DISTANCE
}
