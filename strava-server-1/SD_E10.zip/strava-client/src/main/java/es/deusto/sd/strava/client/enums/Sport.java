package es.deusto.sd.strava.client.enums;

public enum Sport {
		RUNNING, CYCLING
}
